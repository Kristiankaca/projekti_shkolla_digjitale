// Check if elements are present in the DOM
if (!signInBtn || !signInModal || !closeBtns.length || !cityList || !countryInfo || !contactForm) {
    console.error('One or more elements are missing in the DOM.');
    return;
}

// Dynamically create city sections
cities.forEach(city => {
    const listItem = document.createElement('li');
    const link = document.createElement('a');
    link.href = `#${city.toLowerCase()}`;
    link.textContent = city;
    listItem.appendChild(link);
    cityList.appendChild(listItem);

    const section = document.createElement('section');
    section.id = city.toLowerCase();
    section.innerHTML = `
        <h2>${city}</h2>
        <img src="images/${city.toLowerCase()}.jpg" alt="${city}">
        <p>Discover the beauty of ${city}...</p>
    `;
    countryInfo.appendChild(section);
});

// SignIn modal event listeners
signInBtn.addEventListener('click', () => {
    signInModal.style.display = 'block';
});

closeBtns.forEach(btn => btn.addEventListener('click', () => {
    signInModal.style.display = 'none';
}));

window.addEventListener('click', (event) => {
    if (event.target === signInModal) {
        signInModal.style.display = 'none';
    }
});

// Contact form submission
contactForm.addEventListener('submit', (event) => {
    event.preventDefault();
    alert('Message sent!');
});

// Fetch data when a city is clicked
cityList.addEventListener('click', (event) => {
    if (event.target && event.target.tagName === 'A') {
        const cityName = event.target.textContent;

        // Call the API to fetch information for the clicked city
        fetchCityInfo(cityName);
    }
});

// Fetch city information based on the clicked city
function fetchCityInfo(cityName) {
    const options = {
        method: 'POST',
        headers: {
            'x-rapidapi-key': '9c9ea6935dmsh6df8038c4215f8ap10e703jsn6f2883cbf9e7',
            'x-rapidapi-host': 'open-ai21.p.rapidapi.com',
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({
            "city": cityName // Send the city name as part of the request body
        })
    };

    fetch('https://open-ai21.p.rapidapi.com/your-endpoint', options)
        .then(response => response.json())  // Parse the response as JSON
        .then(data => {
            // Handle the response, for example display it in a section or alert it
            console.log(data);

            // Update the country info section with the data returned
            const citySection = document.getElementById(cityName.toLowerCase());

            // Assuming the returned data contains a key "info" with additional information
            if (data.info) {
                citySection.innerHTML += `
                    <p><strong>Additional Info:</strong> ${data.info}</p>
                `;
            } else {
                citySection.innerHTML += `
                    <p><strong>No additional information available.</strong></p>
                `;
            }
        })
        .catch(error => {
            console.error('Error fetching data:', error);
            const citySection = document.getElementById(cityName.toLowerCase());
            citySection.innerHTML += `
                <p><strong>Error loading city information.</strong></p>
            `;
        });
}